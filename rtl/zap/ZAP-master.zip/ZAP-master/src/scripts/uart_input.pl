print `stty raw -echo ; dd bs=1 count=1` while (1);
